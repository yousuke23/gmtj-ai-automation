# 01 ツアー連携ナレッジ（14へ供給）

- `guest-faq.md` — ゲスト向け FAQ（英語優先可）
- `staff-safety.md` — スタッフ向け安全・連絡

Claude Code で `tour/` の Runbook から抽出・同期してよい。
